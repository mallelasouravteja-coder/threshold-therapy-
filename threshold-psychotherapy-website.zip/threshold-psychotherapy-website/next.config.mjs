/**
 * Static export for GitHub Pages.
 * NEXT_PUBLIC_BASE_PATH is set by the GitHub Actions workflow:
 *  - "" when you use a custom domain (public/CNAME exists)
 *  - "/<repo-name>" when the site lives at <user>.github.io/<repo-name>
 */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  trailingSlash: true,
  basePath,
  images: { unoptimized: true },
};

export default nextConfig;
