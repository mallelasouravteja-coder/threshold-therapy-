# Threshold Psychotherapy website

An 8-page Next.js website for a home-visit psychotherapy practice in East London. It's built as a static site, so it's fast and easy to rank, and hosts free on GitHub Pages.

**Pages:** Home, Services, Home visits & areas, Fees, About, FAQ, Resources, Contact (plus Privacy and a 404 page).

## Run it on your computer

You'll need [Node.js 20 or newer](https://nodejs.org).

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## Go live on Vercel (free, for SEO practice)

1. Create a GitHub repository and upload the contents of this folder.
2. Sign up at vercel.com with your GitHub account (Hobby plan).
3. Click **Add New → Project**, import the repository and keep the Next.js defaults.
4. Under **Environment Variables** add `NEXT_PUBLIC_SITE_URL` = your Vercel address, e.g. `https://threshold-therapy.vercel.app`.
5. Click **Deploy**.
6. For Google Search Console, add a **URL prefix** property, choose the **HTML tag** method, copy only the code inside `content="..."`, add it in Vercel as `NEXT_PUBLIC_GOOGLE_VERIFICATION`, redeploy, then verify. Submit `sitemap.xml`.

This is a demo site, so it shows a banner saying it isn't a real clinic and uses a fictional phone number (Ofcom's reserved 020 7946 0xxx range). Remove the `.demo-banner` block in `src/app/layout.tsx` only if it becomes a real practice.

## Put it on GitHub Pages

1. Create a new repository on GitHub and upload everything in this folder (including the hidden `.github` folder).
2. In the repository go to **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Go to **Settings → Secrets and variables → Actions → Variables** and add:
   - `SITE_URL` — your full web address, e.g. `https://www.thresholdpsychotherapy.co.uk` (used for SEO: canonical links, sitemap, social cards)
   - `CRM_WEBHOOK_URL` — the address your CRM gives you for receiving form submissions (see below)
4. Push to the `main` branch. The site builds and publishes automatically in about two minutes. Every later push republishes it.

### Using your own domain (recommended for SEO)

1. Create a file `public/CNAME` containing just your domain, e.g. `www.thresholdpsychotherapy.co.uk`
2. In **Settings → Pages → Custom domain**, enter the same domain and tick **Enforce HTTPS**
3. At your domain registrar, add a CNAME record from `www` to `<your-github-username>.github.io`

The workflow detects the `CNAME` file and sets paths correctly. Without a custom domain the site works at `https://<username>.github.io/<repo-name>/`.

## Connecting the enquiry form to your CRM

The form on the Contact page sends each enquiry to the URL in `CRM_WEBHOOK_URL`, as standard form data. These fields are sent:

`name, postcode, email, phone, service, preferred_times, message, consent, source, page, submitted_at`

This works with any tool that gives you a webhook or form endpoint, for example:

- **Zapier** — "Webhooks by Zapier → Catch Hook", then send to HubSpot, Pipedrive, Zoho, Salesforce, Google Sheets, etc.
- **Make (Integromat)** — "Custom webhook" module
- **HubSpot / Zoho / Pipedrive** — via Zapier or Make
- **Formspree** or **Basin** — if you want email notifications with no CRM

If `CRM_WEBHOOK_URL` isn't set, the form opens the visitor's email app with their details filled in, addressed to the clinic email.

## Editing content

Almost everything is in **`src/lib/site.ts`**: clinic name, phone, email, doctor details, the four services, fees, boroughs and postcodes, testimonials, FAQs and resource articles. Change it there and it updates across the whole site.

Colours and type are in `src/app/globals.css` (see the brand guide in the assets folder).

## SEO already built in

- Unique title and description on every page
- `sitemap.xml` and `robots.txt` generated automatically
- Structured data (schema.org) for the practice, psychologist, services, FAQs and articles, which helps Google show rich results
- Open Graph image for social sharing
- Fonts self-hosted at build time (fast, and no visitor data sent to Google)
- Semantic HTML, alt text, keyboard-accessible navigation and a skip link

After launch, add the site to [Google Search Console](https://search.google.com/search-console), submit `/sitemap.xml`, and set up a **Google Business Profile** as a service-area business covering your six boroughs. For a local practice that matters more than anything else.

## ⚠️ Before you go live

Dr Eleanor Hart is a **fictional placeholder**. Replace, in `src/lib/site.ts` and the About page:

- [ ] Doctor name, photo/portrait, biography and qualifications
- [ ] HCPC number and other registrations (real numbers only)
- [ ] Testimonials: use real, consented reviews or remove the section. Invented reviews breach UK advertising rules (ASA/CAP code).
- [ ] Phone number, email and business hours
- [ ] Fees and policies
- [ ] Privacy notice: have it reviewed so it matches how you actually store data, and register with the ICO
- [ ] `SITE_URL` and `CRM_WEBHOOK_URL` variables
