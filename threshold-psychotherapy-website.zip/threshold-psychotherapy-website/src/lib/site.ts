/**
 * All clinic details live here. Edit this file to change the name,
 * contact details, fees, services and coverage across the whole site.
 *
 * DEMO SITE: built for practising on-page SEO. The phone number is from the
 * Ofcom range reserved for fiction (020 7946 0xxx) and the email domain is fake.
 *
 * ⚠️ PLACEHOLDER DATA: Dr Eleanor Hart, her registration numbers and the
 * testimonials are fictional. Replace them with real details before launch.
 */

export const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

/** Prefix a /public path with the GitHub Pages base path. Use for <img src>. */
export const asset = (path: string) => `${basePath}${path}`;

export const site = {
  name: "Threshold Psychotherapy",
  shortName: "Threshold",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "https://threshold-therapy.vercel.app").replace(/\/$/, ""),
  tagline: "Psychotherapy at home in East London",
  description:
    "Home-visit psychotherapy across East London with an HCPC-registered clinical psychologist. Therapy for anxiety, depression, couples and trauma (EMDR) in your own home.",
  phone: "020 7946 0123",
  phoneHref: "+442079460123",
  email: "hello@threshold-demo.example",
  hours: "Monday to Friday 8am–8pm, Saturday 9am–1pm",
  base: "Walthamstow, London E17",
  crmWebhook: process.env.NEXT_PUBLIC_CRM_WEBHOOK_URL || "",
};

export const doctor = {
  name: "Dr Eleanor Hart",
  role: "Consultant Clinical Psychologist",
  credentials: "DClinPsy, CPsychol",
  hcpc: "PYL000000",
  years: 14,
  registrations: [
    "HCPC registered Practitioner Psychologist (PYL000000)",
    "Chartered Psychologist, British Psychological Society",
    "BABCP accredited CBT psychotherapist",
    "EMDR Europe accredited practitioner",
    "Enhanced DBS checked and fully insured",
  ],
};

export const nav = [
  { href: "/services/", label: "Services" },
  { href: "/home-visits/", label: "Home visits" },
  { href: "/fees/", label: "Fees" },
  { href: "/about/", label: "About" },
  { href: "/faq/", label: "FAQ" },
  { href: "/resources/", label: "Resources" },
];

export type Service = {
  slug: string;
  icon: string;
  name: string;
  short: string;
  intro: string;
  helpsWith: string[];
  approach: string;
  sessions: string;
  length: string;
  fee: string;
};

export const services: Service[] = [
  {
    slug: "anxiety",
    icon: "anxiety",
    name: "Anxiety and stress",
    short: "For worry that won't switch off, panic attacks, health anxiety and work stress.",
    intro:
      "Anxiety often makes it hardest to do the very thing that would help, like travelling to a clinic. Starting therapy at home removes that first hurdle.",
    helpsWith: [
      "Generalised anxiety and constant worry",
      "Panic attacks and agoraphobia",
      "Health anxiety",
      "Social anxiety",
      "Work stress and burnout",
      "OCD (obsessive-compulsive disorder)",
    ],
    approach:
      "Cognitive behavioural therapy (CBT), recommended by NICE for anxiety disorders. We work out what keeps the anxiety going, then practise changing it, sometimes on short trips out from your front door when you're ready.",
    sessions: "Usually 8 to 12 weekly sessions",
    length: "50 minutes",
    fee: "£130",
  },
  {
    slug: "depression",
    icon: "depression",
    name: "Depression and low mood",
    short: "For when everything feels heavy, flat or pointless, and getting out of the house is hard.",
    intro:
      "When you're low, even small tasks take huge effort. Home sessions mean you only need to open the door, and we can start from wherever you are.",
    helpsWith: [
      "Depression and persistent low mood",
      "Postnatal depression",
      "Loss of motivation and withdrawal",
      "Harsh self-criticism",
      "Low self-esteem",
      "Life changes, loss and bereavement",
    ],
    approach:
      "CBT and behavioural activation, with compassion-focused therapy for strong self-criticism. We set small, realistic steps together and build from there.",
    sessions: "Usually 12 to 16 weekly sessions",
    length: "50 minutes",
    fee: "£130",
  },
  {
    slug: "couples",
    icon: "couples",
    name: "Couples and relationship therapy",
    short: "For couples stuck in the same arguments, drifting apart, or recovering from a rupture.",
    intro:
      "Couples therapy at home means no babysitter to arrange and no rushed journey across London after work. You talk in the place where your relationship actually lives.",
    helpsWith: [
      "Repeating arguments and poor communication",
      "Feeling distant or disconnected",
      "Affairs and broken trust",
      "Becoming parents",
      "Big decisions and life transitions",
      "Separating as kindly as possible",
    ],
    approach:
      "Emotionally focused couple therapy (EFT), one of the best-researched couples approaches. We look at the pattern between you rather than deciding who is to blame.",
    sessions: "Usually 10 to 20 sessions, weekly or fortnightly",
    length: "75 minutes",
    fee: "£170",
  },
  {
    slug: "trauma",
    icon: "trauma",
    name: "Trauma and PTSD (EMDR)",
    short: "For flashbacks, nightmares and feeling on edge after a frightening or overwhelming event.",
    intro:
      "Trauma can make the outside world feel unsafe. Working through it in your own home, somewhere you already feel settled, can make the work more manageable.",
    helpsWith: [
      "Post-traumatic stress disorder (PTSD)",
      "Birth trauma",
      "Accidents and assaults",
      "Childhood trauma",
      "Medical trauma",
      "Traumatic bereavement",
    ],
    approach:
      "EMDR (eye movement desensitisation and reprocessing) and trauma-focused CBT, both recommended by NICE for PTSD. We always build stability and coping skills before working on memories.",
    sessions: "Usually 8 to 16 sessions",
    length: "80 minutes",
    fee: "£170",
  },
];

export const boroughs = [
  { name: "Hackney", postcodes: "E2, E5, E8, E9" },
  { name: "Tower Hamlets", postcodes: "E1, E3, E14" },
  { name: "Newham", postcodes: "E6, E7, E12, E13, E15, E16, E20" },
  { name: "Waltham Forest", postcodes: "E4, E10, E11, E17" },
  { name: "Redbridge", postcodes: "E18, IG1–IG4, IG8" },
  { name: "Barking and Dagenham", postcodes: "IG11, RM8–RM10" },
];

/** Postcode districts covered for home visits. */
export const coveredPrefixes = [
  ...Array.from({ length: 18 }, (_, i) => `E${i + 1}`),
  "E20",
  "IG1", "IG2", "IG3", "IG4", "IG8", "IG11",
  "RM8", "RM9", "RM10",
];

export function isCovered(postcode: string) {
  const outward = postcode.toUpperCase().replace(/\s+/g, "").replace(/\d[A-Z]{2}$/, "");
  const district = outward.replace(/[A-Z]$/, ""); // E1W -> E1
  return coveredPrefixes.includes(outward) || coveredPrefixes.includes(district);
}

export const fees = [
  { name: "Free phone consultation", length: "15 minutes", price: "Free", note: "A no-pressure chat to see if we're a good fit." },
  { name: "Initial assessment at home", length: "75 minutes", price: "£150", note: "We talk through what's happening and agree goals." },
  { name: "Individual therapy", length: "50 minutes", price: "£130", note: "Anxiety, depression and most individual work." },
  { name: "Couples therapy", length: "75 minutes", price: "£170", note: "Both partners present, at home." },
  { name: "EMDR and trauma therapy", length: "80 minutes", price: "£170", note: "Longer sessions give time to settle afterwards." },
];

export const testimonials = [
  // ⚠️ Fictional placeholders. Replace with real, consented reviews before launch.
  { quote: "I hadn't left the flat much in a year. Having therapy at my kitchen table was the only way I could have started.", who: "J., Hackney" },
  { quote: "Eleanor came to us after our son was born. Neither of us could have got to a clinic, and it helped more than we expected.", who: "S. and M., Leyton" },
  { quote: "Clear, kind and practical. The EMDR sessions changed how I sleep.", who: "R., Stratford" },
];

export const faqs = [
  {
    q: "What happens in a home visit?",
    a: "I arrive at an agreed time, we sit somewhere quiet and private in your home, and we talk. It's the same evidence-based therapy you'd get in a clinic room. I bring nothing but a notebook, and I leave on time.",
  },
  {
    q: "What do I need to prepare?",
    a: "A room where you won't be overheard for the length of the session, two chairs, and phones on silent. If you share your home, it can help to plan a time when others are out. You don't need to tidy up.",
  },
  {
    q: "Is it confidential if you come to my home?",
    a: "Yes. I arrive without uniform, branding or a marked car, so neighbours won't know why I'm visiting. Everything we discuss is confidential, with the usual legal exceptions if someone is at serious risk. I'll explain these in our first session.",
  },
  {
    q: "Which areas do you cover?",
    a: "Six East London boroughs: Hackney, Tower Hamlets, Newham, Waltham Forest, Redbridge, and Barking and Dagenham. That's postcodes E1 to E18, E20, IG1 to IG4, IG8, IG11 and RM8 to RM10. If you're just outside, ask anyway.",
  },
  {
    q: "Do you offer online or clinic sessions?",
    a: "No. Threshold only offers home visits. If home sessions aren't right for you, I'm happy to recommend trusted colleagues who work online or in clinic.",
  },
  {
    q: "Can I use private health insurance?",
    a: "Many insurers reimburse sessions with an HCPC-registered clinical psychologist. Check with your insurer before you start and ask for an authorisation code. I'll provide receipts for every session so you can claim.",
  },
  {
    q: "Do I need a GP referral?",
    a: "No, you can contact me directly. Some insurers ask for a GP referral before they'll pay, so check your policy.",
  },
  {
    q: "How many sessions will I need?",
    a: "It depends on what you're dealing with. Most people come for between 8 and 16 sessions. We review progress together every few weeks, and you can stop at any time.",
  },
  {
    q: "What's your cancellation policy?",
    a: "Please give at least 48 hours' notice to cancel or move a session. Sessions cancelled with less notice are charged in full, as the time and travel can't usually be rebooked.",
  },
  {
    q: "Is this an emergency service?",
    a: "No. If you're in immediate danger, call 999 or go to A&E. For urgent mental health support, call NHS 111 and choose option 2, or call Samaritans free on 116 123, any time of day or night.",
  },
];

export const articles = [
  {
    slug: "starting-therapy-at-home",
    title: "Starting therapy at home: what to expect",
    summary: "A practical guide to your first home session, from where to sit to what we'll talk about.",
    minutes: 4,
    body: [
      "Most people feel a bit nervous before a first session. That's normal, and it usually fades within the first ten minutes.",
      "Choose a room where you won't be overheard. A kitchen table works well, and so does a living room with the door closed. Two chairs at a slight angle are better than sitting directly opposite each other.",
      "In the first session I'll ask about what's been happening, how it affects your day-to-day life, and what you'd like to be different. You decide how much to share. We'll finish by agreeing whether to continue and what we'll focus on.",
      "After I leave, give yourself a little time before jumping back into tasks. A short walk or a cup of tea helps the session settle.",
    ],
  },
  {
    slug: "anxiety-five-minute-reset",
    title: "A five-minute reset for anxious moments",
    summary: "A simple breathing and grounding exercise you can use anywhere.",
    minutes: 3,
    body: [
      "When anxiety rises, your body prepares for danger: your heart speeds up, breathing gets shallow and your thoughts race. You can't argue yourself out of it, but you can send your body a different signal.",
      "Breathe in gently through your nose for a count of four, then out through your mouth for a count of six. A longer out-breath is what calms the nervous system. Repeat for two minutes.",
      "Then name five things you can see, four you can hear, three you can touch, two you can smell and one you can taste. This brings your attention back to the present.",
      "This won't fix anxiety on its own, but it can take the edge off. If anxiety is getting in the way of your life, therapy can help with the cause.",
    ],
  },
  {
    slug: "when-to-try-couples-therapy",
    title: "When is it time to try couples therapy?",
    summary: "Signs that some outside help could make a difference, and what couples therapy is not.",
    minutes: 4,
    body: [
      "Many couples wait years between first noticing problems and asking for help. Earlier is usually easier, because patterns have had less time to set.",
      "Common signs include the same argument on repeat, feeling more like flatmates than partners, avoiding certain topics, or struggling to recover after a big event like a new baby, a bereavement or an affair.",
      "Couples therapy isn't about deciding who's right. It's about understanding the pattern you both get caught in, and finding a way to reach each other again.",
      "It also isn't only for couples who want to stay together. Some couples use therapy to separate with less pain, especially when children are involved.",
    ],
  },
];
