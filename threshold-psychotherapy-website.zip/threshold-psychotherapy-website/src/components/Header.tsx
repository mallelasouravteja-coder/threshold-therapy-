"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { asset, nav, site } from "@/lib/site";

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  const isCurrent = (href: string) =>
    pathname === href || pathname === href.replace(/\/$/, "");

  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <Link href="/" className="brand" aria-label={`${site.name}, home`}>
          <img src={asset("/images/logo-mark.svg")} alt="" width={42} height={42} />
          <span>
            <span className="brand__name">{site.shortName}</span>
            <span className="brand__sub">{site.tagline}</span>
          </span>
        </Link>

        <button
          type="button"
          className="menu-toggle"
          aria-expanded={open}
          aria-controls="site-nav"
          onClick={() => setOpen((o) => !o)}
        >
          {open ? "Close" : "Menu"}
        </button>

        <nav id="site-nav" aria-label="Main" className={`nav${open ? " is-open" : ""}`}>
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isCurrent(item.href) ? "page" : undefined}
            >
              {item.label}
            </Link>
          ))}
          <Link href="/contact/" className="btn">
            Book a free call
          </Link>
        </nav>
      </div>
    </header>
  );
}
