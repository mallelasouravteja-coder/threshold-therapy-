import Link from "next/link";
import { boroughs, doctor, services, site } from "@/lib/site";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <h2>{site.name}</h2>
            <p>
              Home-visit psychotherapy with {doctor.name}, {doctor.role.toLowerCase()}. Based in{" "}
              {site.base}. No clinic premises: all sessions take place in your home.
            </p>
            <p>
              <a href={`tel:${site.phoneHref}`}>{site.phone}</a>
              <br />
              <a href={`mailto:${site.email}`}>{site.email}</a>
            </p>
          </div>

          <div>
            <h2>Therapy</h2>
            <ul>
              {services.map((s) => (
                <li key={s.slug}>
                  <Link href={`/services/#${s.slug}`}>{s.name}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2>Areas</h2>
            <ul>
              {boroughs.map((b) => (
                <li key={b.name}>
                  <Link href="/home-visits/#areas">{b.name}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="footer-crisis">
            <h2>Need help right now?</h2>
            <p className="small" style={{ margin: 0 }}>
              We're not an emergency service. If you're in danger, call <a href="tel:999">999</a>.
              For urgent mental health help call <a href="tel:111">NHS 111</a> and choose option 2,
              or Samaritans free on <a href="tel:116123">116 123</a>, day or night.
            </p>
          </div>
        </div>

        <div className="footer-base">
          <span>
            © {year} {site.name}. HCPC registration {doctor.hcpc}.
          </span>
          <span>
            <Link href="/privacy/">Privacy</Link>
            <Link href="/contact/" style={{ marginLeft: 16 }}>Contact</Link>
          </span>
        </div>
      </div>
    </footer>
  );
}
