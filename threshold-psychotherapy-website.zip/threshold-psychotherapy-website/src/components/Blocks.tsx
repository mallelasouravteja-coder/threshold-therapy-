import Link from "next/link";
import { site } from "@/lib/site";

export function PageIntro({
  title,
  children,
  crumb,
}: {
  title: string;
  children?: React.ReactNode;
  crumb: string;
}) {
  return (
    <section className="page-intro">
      <div className="container">
        <nav aria-label="Breadcrumb" className="crumbs">
          <Link href="/">Home</Link> / <span aria-current="page">{crumb}</span>
        </nav>
        <h1>{title}</h1>
        {children}
      </div>
    </section>
  );
}

export function CtaBand({
  title = "Not sure if therapy at home is right for you?",
  text = "Book a free 15-minute phone call. We'll talk about what's going on and whether I can help, with no obligation.",
}: {
  title?: string;
  text?: string;
}) {
  return (
    <section className="cta-band section">
      <div className="container cta-band__inner">
        <div>
          <h2>{title}</h2>
          <p style={{ margin: 0 }}>{text}</p>
        </div>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <Link href="/contact/" className="btn btn--light">
            Book a free call
          </Link>
          <a href={`tel:${site.phoneHref}`} className="btn btn--light" style={{ background: "transparent", color: "var(--paper)" }}>
            Call {site.phone}
          </a>
        </div>
      </div>
    </section>
  );
}

export function CrisisNote() {
  return (
    <aside className="crisis" aria-label="Urgent help">
      <h2>If you need urgent help</h2>
      <p>
        This service can't respond to emergencies. If you're in immediate danger call{" "}
        <a href="tel:999">999</a> or go to A&amp;E. For urgent mental health support call{" "}
        <a href="tel:111">NHS 111</a> and choose option 2, or call Samaritans free on{" "}
        <a href="tel:116123">116 123</a>, any time.
      </p>
    </aside>
  );
}

export function JsonLd({ data }: { data: object }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
