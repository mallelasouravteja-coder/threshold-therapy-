"use client";

import Link from "next/link";
import { useState } from "react";
import { isCovered, services, site } from "@/lib/site";

/**
 * Enquiry form that sends to your CRM.
 *
 * Set NEXT_PUBLIC_CRM_WEBHOOK_URL (GitHub repo variable CRM_WEBHOOK_URL) to any
 * endpoint that accepts form posts: a Zapier or Make webhook, HubSpot/Pipedrive
 * via Zapier, Formspree, a Google Apps Script, etc.
 *
 * Data is sent as application/x-www-form-urlencoded, which most webhook tools
 * accept and which avoids CORS preflight problems on a static site.
 * If no webhook is set, the form opens the visitor's email app instead.
 */

type Status = "idle" | "sending" | "sent" | "error";

export default function BookingForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [postcode, setPostcode] = useState("");
  const outside = postcode.trim().length >= 3 && !isCovered(postcode);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);

    if (data.get("website")) return; // honeypot: bots fill hidden fields

    const payload = new URLSearchParams();
    for (const [key, value] of data.entries()) {
      if (key === "website") continue;
      const existing = payload.get(key);
      payload.set(key, existing ? `${existing}, ${value}` : String(value));
    }
    payload.set("source", "Website enquiry form");
    payload.set("page", window.location.pathname);
    payload.set("submitted_at", new Date().toISOString());

    if (!site.crmWebhook) {
      const body = [...payload.entries()].map(([k, v]) => `${k}: ${v}`).join("\n");
      window.location.href = `mailto:${site.email}?subject=${encodeURIComponent(
        "Home visit enquiry"
      )}&body=${encodeURIComponent(body)}`;
      return;
    }

    setStatus("sending");
    try {
      const res = await fetch(site.crmWebhook, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: payload.toString(),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("sent");
      form.reset();
      setPostcode("");
    } catch {
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <div className="notice notice--ok" role="status">
        <h2 style={{ fontSize: "1.6rem" }}>Thank you, your enquiry has been sent</h2>
        <p style={{ margin: 0 }}>
          I'll reply within one working day to arrange your free 15-minute call. If you don't
          hear back, please check your spam folder or call {site.phone}.
        </p>
      </div>
    );
  }

  return (
    <form className="form" onSubmit={onSubmit} noValidate={false}>
      <div className="form__row">
        <div className="field">
          <label htmlFor="name">Your name</label>
          <input id="name" name="name" autoComplete="name" required />
        </div>
        <div className="field">
          <label htmlFor="postcode">
            Postcode <span className="hint">So I can check you're in the visiting area</span>
          </label>
          <input
            id="postcode"
            name="postcode"
            autoComplete="postal-code"
            required
            value={postcode}
            onChange={(e) => setPostcode(e.target.value)}
            aria-describedby={outside ? "postcode-note" : undefined}
          />
        </div>
      </div>

      {outside && (
        <p id="postcode-note" className="notice notice--warn" role="status" style={{ margin: 0 }}>
          That postcode looks outside the usual visiting area. Send your enquiry anyway. I can
          sometimes travel a little further, or recommend someone closer.
        </p>
      )}

      <div className="form__row">
        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" name="email" type="email" autoComplete="email" required />
        </div>
        <div className="field">
          <label htmlFor="phone">
            Phone <span className="hint">For the free call</span>
          </label>
          <input id="phone" name="phone" type="tel" autoComplete="tel" required />
        </div>
      </div>

      <div className="field">
        <label htmlFor="service">What would you like help with?</label>
        <select id="service" name="service" defaultValue="">
          <option value="" disabled>
            Choose one
          </option>
          {services.map((s) => (
            <option key={s.slug} value={s.name}>
              {s.name}
            </option>
          ))}
          <option value="Not sure">I'm not sure yet</option>
        </select>
      </div>

      <div className="field">
        <fieldset>
          <legend>Best times for a home visit</legend>
          <div className="checks">
            {["Weekday mornings", "Weekday afternoons", "Weekday evenings", "Saturday mornings"].map((t) => (
              <label key={t}>
                <input type="checkbox" name="preferred_times" value={t} /> {t}
              </label>
            ))}
          </div>
        </fieldset>
      </div>

      <div className="field">
        <label htmlFor="message">
          Anything you'd like me to know <span className="hint">Optional. A sentence or two is plenty.</span>
        </label>
        <textarea id="message" name="message" />
      </div>

      <div className="hp" aria-hidden="true">
        <label htmlFor="website">Leave this empty</label>
        <input id="website" name="website" tabIndex={-1} autoComplete="off" />
      </div>

      <label className="consent">
        <input type="checkbox" name="consent" value="yes" required />
        <span>
          I agree to {site.name} storing these details to respond to my enquiry, as described in
          the <Link href="/privacy/">privacy notice</Link>.
        </span>
      </label>

      {status === "error" && (
        <p className="notice notice--error" role="alert" style={{ margin: 0 }}>
          Your enquiry didn't send. Check your connection and try again, or email{" "}
          <a href={`mailto:${site.email}`}>{site.email}</a> or call {site.phone}.
        </p>
      )}

      <div>
        <button type="submit" className="btn" disabled={status === "sending"}>
          {status === "sending" ? "Sending enquiry…" : "Send enquiry"}
        </button>
        <p className="small muted" style={{ marginTop: 12 }}>
          Please don't include anything urgent. This inbox isn't monitored out of hours.
        </p>
      </div>
    </form>
  );
}
