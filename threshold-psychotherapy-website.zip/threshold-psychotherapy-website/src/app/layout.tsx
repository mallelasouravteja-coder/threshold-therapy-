import type { Metadata, Viewport } from "next";
import { Figtree, Newsreader } from "next/font/google";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { JsonLd } from "@/components/Blocks";
import { boroughs, doctor, services, site } from "@/lib/site";
import "./globals.css";

// Fonts are downloaded at build time and self-hosted (no requests to Google from visitors).
const serif = Newsreader({ subsets: ["latin"], variable: "--font-serif", axes: ["opsz"], display: "swap" });
const sans = Figtree({ subsets: ["latin"], variable: "--font-sans", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: `Home-Visit Psychotherapy in East London | ${site.name}`,
    template: `%s | ${site.name}`,
  },
  description: site.description,
  applicationName: site.name,
  keywords: [
    "home visit therapist East London",
    "psychotherapy at home London",
    "therapist Hackney",
    "therapist Walthamstow",
    "anxiety therapy East London",
    "couples therapy East London",
    "EMDR East London",
    "clinical psychologist home visits",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: "en_GB",
    siteName: site.name,
    title: `Home-visit psychotherapy in East London | ${site.name}`,
    description: site.description,
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: site.name }],
  },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
  // Google Search Console: set NEXT_PUBLIC_GOOGLE_VERIFICATION to the code from the HTML tag method
  verification: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION
    ? { google: process.env.NEXT_PUBLIC_GOOGLE_VERIFICATION }
    : undefined,
};

export const viewport: Viewport = {
  themeColor: "#EDF1EC",
  width: "device-width",
  initialScale: 1,
};

const orgSchema = {
  "@context": "https://schema.org",
  "@type": ["MedicalBusiness", "Psychologist"],
  "@id": `${site.url}/#practice`,
  name: site.name,
  description: site.description,
  url: site.url,
  telephone: site.phoneHref,
  email: site.email,
  image: `${site.url}/og-image.png`,
  logo: `${site.url}/icon-512.png`,
  priceRange: "££",
  medicalSpecialty: "Psychiatric",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Walthamstow, London",
    postalCode: "E17",
    addressCountry: "GB",
  },
  areaServed: boroughs.map((b) => ({ "@type": "AdministrativeArea", name: `London Borough of ${b.name}` })),
  employee: {
    "@type": "Person",
    name: doctor.name,
    jobTitle: doctor.role,
  },
  availableService: services.map((s) => ({
    "@type": "MedicalTherapy",
    name: s.name,
    description: s.short,
  })),
  openingHoursSpecification: [
    { "@type": "OpeningHoursSpecification", dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], opens: "08:00", closes: "20:00" },
    { "@type": "OpeningHoursSpecification", dayOfWeek: "Saturday", opens: "09:00", closes: "13:00" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB" className={`${serif.variable} ${sans.variable}`}>
      <body>
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <div className="demo-banner" role="note">
          Demo website built for SEO practice. Threshold Psychotherapy is not a real clinic. If you
          need support now, call NHS 111 and choose option 2, or Samaritans free on{" "}
          <a href="tel:116123">116 123</a>.
        </div>
        <Header />
        <main id="main">{children}</main>
        <Footer />
        <JsonLd data={orgSchema} />
      </body>
    </html>
  );
}
