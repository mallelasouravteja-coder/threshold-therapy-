import type { Metadata } from "next";
import Link from "next/link";
import { CtaBand, PageIntro } from "@/components/Blocks";
import { asset, boroughs, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Home Visits & Areas Covered in East London",
  description:
    "Therapy home visits across Hackney, Tower Hamlets, Newham, Waltham Forest, Redbridge, and Barking & Dagenham. See postcodes covered and how a home session works.",
  alternates: { canonical: "/home-visits/" },
};

export default function HomeVisitsPage() {
  return (
    <>
      <PageIntro title="Home visits in East London" crumb="Home visits">
        <p>
          Every session takes place in your home. Here's what that looks like, what you'll need, and
          where I can visit.
        </p>
      </PageIntro>

      <section className="section section--paper">
        <div className="container split split--top">
          <div>
            <h2>What a home session is like</h2>
            <p>
              I arrive at the agreed time, we settle somewhere quiet, and we talk for the length of the
              session. It's the same structured, evidence-based therapy you'd get in a clinic, just
              without the journey.
            </p>
            <p>
              I keep a consistent day and time each week, so sessions become a fixed point you can plan
              around. Early morning, evening and Saturday morning slots are available.
            </p>
          </div>
          <div>
            <h2>What you'll need</h2>
            <ul className="ticks">
              <li>A room where you won't be overheard for the session</li>
              <li>Two chairs, ideally at a slight angle</li>
              <li>Phones on silent and the TV off</li>
              <li>If others live with you, a time when they're out or busy elsewhere</li>
            </ul>
            <p className="muted">There's no need to tidy up. Honestly.</p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container split">
          <div>
            <h2>Privacy and safety</h2>
            <ul className="badges">
              <li>
                <img src={asset("/images/icons/icon-lock.svg")} alt="" width={28} height={28} />
                <span>
                  <strong>Discreet visits.</strong> No uniform, no branded car, nothing to tell neighbours
                  why I'm there.
                </span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-shield.svg")} alt="" width={28} height={28} />
                <span>
                  <strong>Checked and insured.</strong> Enhanced DBS check, professional indemnity
                  insurance and HCPC registration.
                </span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-home-visit.svg")} alt="" width={28} height={28} />
                <span>
                  <strong>Clear boundaries.</strong> Sessions start and end on time, and I don't accept
                  food or gifts, so the time stays focused on you.
                </span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-clock.svg")} alt="" width={28} height={28} />
                <span>
                  <strong>Safe working.</strong> I follow a lone-working policy, so a colleague always
                  knows where I am. Your details are never shared.
                </span>
              </li>
            </ul>
          </div>
          <img
            className="figure"
            src={asset("/images/kitchen-table.svg")}
            alt="Two mugs of tea on a kitchen table by a window"
            width={480}
            height={360}
            loading="lazy"
          />
        </div>
      </section>

      <section id="areas" className="section section--lichen" style={{ scrollMarginTop: 80 }}>
        <div className="container split split--top">
          <div>
            <h2>Areas covered</h2>
            <p>
              I visit homes in six East London boroughs, travelling from {site.base}. Travel is
              included in every fee.
            </p>
            <ul className="areas">
              {boroughs.map((b) => (
                <li key={b.name}>
                  <strong>{b.name}</strong>
                  <span>{b.postcodes}</span>
                </li>
              ))}
            </ul>
            <p className="small">
              Just outside these areas? <Link href="/contact/">Get in touch anyway</Link>. I can
              sometimes travel a little further, or recommend a trusted colleague nearer to you.
            </p>
          </div>
          <img
            className="figure"
            src={asset("/images/map-east-london-coverage.svg")}
            alt="Map showing Hackney, Tower Hamlets, Newham, Waltham Forest, Redbridge, and Barking and Dagenham"
            width={640}
            height={440}
            loading="lazy"
          />
        </div>
      </section>

      <CtaBand title="Live in one of these areas?" text="Book a free 15-minute call and we'll find a regular time that works for you." />
    </>
  );
}
