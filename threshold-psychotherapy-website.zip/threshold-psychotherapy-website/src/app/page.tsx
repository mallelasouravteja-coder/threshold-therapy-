import Link from "next/link";
import { CtaBand } from "@/components/Blocks";
import { asset, boroughs, doctor, services, site, testimonials } from "@/lib/site";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="hero">
        <div className="container hero__grid">
          <div>
            <h1>Therapy that comes to your front door</h1>
            <p className="lede">
              Private psychotherapy in your own home, anywhere in East London. For anxiety,
              depression, relationships and trauma, with an HCPC-registered clinical psychologist.
            </p>
            <div className="btn-row">
              <Link href="/contact/" className="btn">
                Book a free 15-minute call
              </Link>
              <Link href="/home-visits/" className="btn btn--quiet">
                Check if I visit your area
              </Link>
            </div>
            <p className="hero__note">
              <img src={asset("/images/icons/icon-shield.svg")} alt="" width={28} height={28} />
              {doctor.name}, {doctor.credentials}. {doctor.years} years' experience, 9 in the NHS.
            </p>
          </div>
          <div className="hero__art">
            <div className="arch">
              <img
                src={asset("/images/hero-terrace.svg")}
                alt="Illustration of an East London terrace with one front door open and warm light spilling out"
                width={720}
                height={540}
                fetchPriority="high"
              />
            </div>
            <div className="threshold-step" aria-hidden="true" />
          </div>
        </div>
      </section>

      {/* How it works — a genuine sequence */}
      <section className="section section--paper">
        <div className="container">
          <h2>How home therapy works</h2>
          <p className="lede">No waiting rooms and no journey. Here's what happens after you get in touch.</p>
          <ol className="steps">
            <li>
              <h3>A free phone call</h3>
              <p>
                Fifteen minutes to talk about what's going on and whether home therapy could help.
                No obligation.
              </p>
            </li>
            <li>
              <h3>An assessment at home</h3>
              <p>
                A longer first visit, at a time that suits you. We get to know what you need and agree
                goals together.
              </p>
            </li>
            <li>
              <h3>Regular sessions</h3>
              <p>
                Usually weekly, same day and time. Evidence-based therapy at your kitchen table,
                reviewed together every few weeks.
              </p>
            </li>
          </ol>
        </div>
      </section>

      {/* Services */}
      <section className="section">
        <div className="container">
          <h2>What I can help with</h2>
          <p className="lede">
            Four areas I specialise in, each using approaches recommended by NICE.
          </p>
          <ul className="service-list">
            {services.map((s) => (
              <li key={s.slug}>
                <Link href={`/services/#${s.slug}`}>
                  <img src={asset(`/images/icons/icon-${s.icon}.svg`)} alt="" width={56} height={56} />
                  <div>
                    <h3>{s.name}</h3>
                    <p>{s.short}</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Why home */}
      <section className="section section--lichen">
        <div className="container split">
          <img
            className="figure"
            src={asset("/images/kitchen-table.svg")}
            alt="Two mugs of tea on a kitchen table by a window"
            width={480}
            height={360}
            loading="lazy"
          />
          <div>
            <h2>Why see a therapist at home?</h2>
            <p>
              For many people, the hardest part of therapy is getting there. Home visits remove that
              barrier, and often the work moves faster because you're somewhere you feel settled.
            </p>
            <ul className="ticks">
              <li>No travel when you're anxious, low or exhausted</li>
              <li>No childcare to arrange for new parents</li>
              <li>Easier for people with health conditions or limited mobility</li>
              <li>Couples can talk where their relationship actually happens</li>
              <li>Discreet: no uniform, no branded car, no clinic sign</li>
            </ul>
          </div>
        </div>
      </section>

      {/* About teaser */}
      <section className="section">
        <div className="container split split--wide-left">
          <div>
            <p className="pull">
              "Therapy often moves faster when people are somewhere they already feel safe. For most of
              us, that's home."
            </p>
            <p>
              I'm {doctor.name}, a clinical psychologist who grew up in Leytonstone. I spent nine years in
              NHS community mental health teams across East London before starting Threshold, so I know
              these streets and the pressures of living here.
            </p>
            <Link href="/about/" className="btn btn--quiet" style={{ marginTop: 8 }}>
              About Eleanor
            </Link>
          </div>
          <div style={{ maxWidth: 360 }}>
            <div className="arch">
              <img
                src={asset("/images/portrait-dr-eleanor-hart.svg")}
                alt={`Illustrated portrait of ${doctor.name}`}
                width={400}
                height={500}
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section section--paper">
        <div className="container">
          <h2>What clients say</h2>
          <div className="quotes">
            {testimonials.map((t) => (
              <figure key={t.who}>
                <blockquote>"{t.quote}"</blockquote>
                <figcaption>{t.who}</figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* Areas */}
      <section className="section">
        <div className="container split split--top">
          <div>
            <h2>Home visits across six East London boroughs</h2>
            <p>
              I travel from {site.base}, so visits are usually on time and travel is included in the fee.
            </p>
            <ul className="areas">
              {boroughs.map((b) => (
                <li key={b.name}>
                  <strong>{b.name}</strong>
                  <span>{b.postcodes}</span>
                </li>
              ))}
            </ul>
            <Link href="/home-visits/" className="btn btn--quiet">
              More about home visits
            </Link>
          </div>
          <img
            className="figure"
            src={asset("/images/map-east-london-coverage.svg")}
            alt="Map of the six East London boroughs covered for home visits"
            width={640}
            height={440}
            loading="lazy"
          />
        </div>
      </section>

      <CtaBand />
    </>
  );
}
