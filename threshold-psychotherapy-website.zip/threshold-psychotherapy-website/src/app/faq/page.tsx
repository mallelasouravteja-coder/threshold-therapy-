import type { Metadata } from "next";
import { CrisisNote, CtaBand, JsonLd, PageIntro } from "@/components/Blocks";
import { faqs } from "@/lib/site";

export const metadata: Metadata = {
  title: "Questions About Home-Visit Therapy",
  description:
    "Answers to common questions about home-visit psychotherapy in East London: confidentiality, preparation, insurance, areas covered and cancellations.",
  alternates: { canonical: "/faq/" },
};

export default function FaqPage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };

  return (
    <>
      <PageIntro title="Common questions" crumb="FAQ">
        <p>If your question isn't here, ask it in the free phone call.</p>
      </PageIntro>

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="faq">
            {faqs.map((f, i) => (
              <details key={f.q} open={i === 0}>
                <summary>{f.q}</summary>
                <div>
                  <p>{f.a}</p>
                </div>
              </details>
            ))}
          </div>
          <div style={{ maxWidth: 820, marginTop: 48 }}>
            <CrisisNote />
          </div>
        </div>
      </section>

      <CtaBand />
      <JsonLd data={schema} />
    </>
  );
}
