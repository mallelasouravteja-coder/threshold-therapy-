import type { Metadata } from "next";
import Link from "next/link";
import { CtaBand, PageIntro } from "@/components/Blocks";
import { fees } from "@/lib/site";

export const metadata: Metadata = {
  title: "Fees for Home-Visit Therapy",
  description:
    "Clear prices for home-visit therapy in East London. Free 15-minute consultation, individual sessions £130, couples and EMDR £170. Travel included.",
  alternates: { canonical: "/fees/" },
};

export default function FeesPage() {
  return (
    <>
      <PageIntro title="Fees" crumb="Fees">
        <p>Simple, fixed prices. Travel within the visiting area is always included.</p>
      </PageIntro>

      <section className="section section--paper" style={{ paddingTop: 48 }}>
        <div className="container">
          <table className="fee-table">
            <caption className="hp">Session fees</caption>
            <thead>
              <tr>
                <th scope="col">Session</th>
                <th scope="col" className="len">Length</th>
                <th scope="col">Fee</th>
              </tr>
            </thead>
            <tbody>
              {fees.map((f) => (
                <tr key={f.name}>
                  <td>
                    <span className="name">{f.name}</span>
                    <span className="note">{f.note}</span>
                  </td>
                  <td className="len">{f.length}</td>
                  <td className="price">{f.price}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="section">
        <div className="container split split--top">
          <div>
            <h2>Paying for sessions</h2>
            <p>
              You'll receive an invoice after each session, payable by bank transfer or card within
              seven days. Couples can choose who the invoice goes to.
            </p>
            <h3>Cancellations</h3>
            <p>
              Please give at least 48 hours' notice to cancel or move a session. Late cancellations are
              charged in full, because the time and travel usually can't be rebooked. I'll always be
              flexible if something genuinely unexpected happens.
            </p>
            <h3>Reduced-fee places</h3>
            <p>
              I keep a small number of reduced-fee places for people on low incomes. Ask about these in
              your free call.
            </p>
          </div>
          <div className="panel panel--lichen">
            <h2>Health insurance</h2>
            <p>
              Many private health insurers cover sessions with an HCPC-registered clinical psychologist.
              Before you start:
            </p>
            <ul className="ticks">
              <li>Check your policy covers outpatient mental health</li>
              <li>Ask whether you need a GP referral</li>
              <li>Get an authorisation code and how many sessions are covered</li>
            </ul>
            <p style={{ margin: 0 }}>
              I'll provide a receipt for every session so you can claim back.{" "}
              <Link href="/faq/">More questions answered</Link>.
            </p>
          </div>
        </div>
      </section>

      <CtaBand title="Start with a free call" text="Fifteen minutes, no obligation, and no charge. We'll talk through what you need and what it would cost." />
    </>
  );
}
