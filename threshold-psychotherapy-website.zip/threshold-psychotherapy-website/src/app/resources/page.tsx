import type { Metadata } from "next";
import { CrisisNote, CtaBand, JsonLd, PageIntro } from "@/components/Blocks";
import { articles, doctor, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Resources: Practical Guides on Anxiety, Therapy and Relationships",
  description:
    "Short, practical guides from a clinical psychologist: starting therapy at home, calming anxiety in five minutes, and when to try couples therapy.",
  alternates: { canonical: "/resources/" },
};

const links = [
  { name: "NHS Talking Therapies", href: "https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/talking-therapies-and-counselling/nhs-talking-therapies/", note: "Free NHS therapy you can refer yourself to." },
  { name: "Mind", href: "https://www.mind.org.uk/", note: "Clear information on mental health conditions and support." },
  { name: "Relate", href: "https://www.relate.org.uk/", note: "Relationship advice and support." },
  { name: "Samaritans", href: "https://www.samaritans.org/", note: "Call 116 123 free, any time, about anything." },
];

export default function ResourcesPage() {
  const schema = articles.map((a) => ({
    "@context": "https://schema.org",
    "@type": "Article",
    headline: a.title,
    description: a.summary,
    author: { "@type": "Person", name: doctor.name },
    publisher: { "@id": `${site.url}/#practice` },
    mainEntityOfPage: `${site.url}/resources/#${a.slug}`,
  }));

  return (
    <>
      <PageIntro title="Resources" crumb="Resources">
        <p>Short, practical guides you can read in a few minutes, plus trusted places to find more help.</p>
        <ul className="article-index">
          {articles.map((a) => (
            <li key={a.slug}>
              <a href={`#${a.slug}`}>
                <strong>{a.title}</strong>
                <span>{a.summary}</span>
              </a>
            </li>
          ))}
        </ul>
      </PageIntro>

      <div className="container">
        {articles.map((a) => (
          <article key={a.slug} id={a.slug} className="article">
            <h2>{a.title}</h2>
            <p className="meta">
              By {doctor.name}. {a.minutes} minute read.
            </p>
            {a.body.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </article>
        ))}
      </div>

      <section className="section section--paper">
        <div className="container">
          <h2>Other places to find help</h2>
          <ul className="areas" style={{ maxWidth: 900 }}>
            {links.map((l) => (
              <li key={l.name}>
                <strong>
                  <a href={l.href} rel="noopener">{l.name}</a>
                </strong>
                <span>{l.note}</span>
              </li>
            ))}
          </ul>
          <div style={{ maxWidth: 820, marginTop: 40 }}>
            <CrisisNote />
          </div>
        </div>
      </section>

      <CtaBand />
      <JsonLd data={schema} />
    </>
  );
}
