import type { Metadata } from "next";
import { CtaBand, JsonLd, PageIntro } from "@/components/Blocks";
import { asset, doctor, site } from "@/lib/site";

export const metadata: Metadata = {
  title: `About ${doctor.name}, Clinical Psychologist`,
  description: `${doctor.name} is an HCPC-registered clinical psychologist with ${doctor.years} years' experience, offering home-visit therapy across East London.`,
  alternates: { canonical: "/about/" },
};

export default function AboutPage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: doctor.name,
    jobTitle: doctor.role,
    worksFor: { "@id": `${site.url}/#practice` },
    hasCredential: doctor.registrations,
    knowsLanguage: ["en", "fr"],
    homeLocation: { "@type": "Place", name: "Walthamstow, London" },
  };

  return (
    <>
      <PageIntro title={`Hello, I'm Eleanor`} crumb="About" />

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container split split--top split--wide-left">
          <div>
            <p className="lede">
              I'm a consultant clinical psychologist and psychotherapist. I grew up in Leytonstone, trained
              at UCL, and have spent my whole career working in East London.
            </p>
            <p>
              For nine years I worked in NHS community mental health teams. Many of the people I saw found
              it hard to get to a clinic: new parents, carers, people whose anxiety made the journey
              impossible, people recovering from trauma or illness. I started seeing some of them at home,
              and noticed something. Therapy often moved faster when people were somewhere they felt safe.
            </p>
            <p>
              In 2021 I set up Threshold to offer that on purpose. Unhurried, evidence-based therapy in your
              own home, from someone who knows these streets.
            </p>

            <h2 style={{ marginTop: "1.4em" }}>How I work</h2>
            <p>
              I draw on CBT, EMDR, compassion-focused therapy and emotionally focused couple therapy,
              choosing what fits you rather than the other way round. I'll explain what we're doing and why,
              and we'll agree clear goals in the first session.
            </p>
            <p>
              People tell me I'm warm but direct, and that I don't take myself too seriously. Therapy is
              hard work, but it doesn't have to be grim.
            </p>

            <h2 style={{ marginTop: "1.4em" }}>Outside work</h2>
            <p>
              You'll probably find me walking my dog, Pickle, on Walthamstow Marshes, or swimming at London
              Fields Lido, whatever the weather. I read too much crime fiction and volunteer with a local
              bereavement charity.
            </p>
          </div>

          <div>
            <div className="arch" style={{ maxWidth: 380 }}>
              <img
                src={asset("/images/portrait-dr-eleanor-hart.svg")}
                alt={`Illustrated portrait of ${doctor.name}`}
                width={400}
                height={500}
              />
            </div>
            <div className="threshold-step" style={{ maxWidth: 380 }} aria-hidden="true" />

            <div className="panel" style={{ marginTop: 32 }}>
              <h2 style={{ fontSize: "1.5rem" }}>Qualifications and registration</h2>
              <ul className="badges">
                {doctor.registrations.map((r) => (
                  <li key={r}>
                    <img src={asset("/images/icons/icon-shield.svg")} alt="" width={28} height={28} />
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
              <p className="small muted" style={{ marginTop: 16, marginBottom: 0 }}>
                You can check my registration on the{" "}
                <a href="https://www.hcpc-uk.org/check-the-register/" rel="noopener">
                  HCPC register
                </a>
                .
              </p>
            </div>
          </div>
        </div>
      </section>

      <CtaBand title="Want to see if we'd work well together?" />
      <JsonLd data={schema} />
    </>
  );
}
