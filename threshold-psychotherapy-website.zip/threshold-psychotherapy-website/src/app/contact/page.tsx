import type { Metadata } from "next";
import BookingForm from "@/components/BookingForm";
import { CrisisNote, PageIntro } from "@/components/Blocks";
import { asset, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Book a Free Consultation",
  description:
    "Book a free 15-minute phone consultation for home-visit therapy in East London. Reply within one working day.",
  alternates: { canonical: "/contact/" },
};

export default function ContactPage() {
  return (
    <>
      <PageIntro title="Book a free call" crumb="Contact">
        <p>
          Tell me a little about what you're looking for and I'll be in touch within one working day to
          arrange a free 15-minute phone call.
        </p>
      </PageIntro>

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container split split--top split--wide-left">
          <div className="panel">
            <BookingForm />
          </div>

          <div>
            <h2 style={{ fontSize: "1.7rem" }}>Prefer to call or email?</h2>
            <ul className="badges" style={{ marginBottom: 32 }}>
              <li>
                <img src={asset("/images/icons/icon-phone.svg")} alt="" width={28} height={28} />
                <span>
                  <a href={`tel:${site.phoneHref}`}>{site.phone}</a>
                  <br />
                  <span className="small muted">If I'm with a client, leave a message and I'll call back.</span>
                </span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-mail.svg")} alt="" width={28} height={28} />
                <span>
                  <a href={`mailto:${site.email}`}>{site.email}</a>
                </span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-clock.svg")} alt="" width={28} height={28} />
                <span>{site.hours}</span>
              </li>
              <li>
                <img src={asset("/images/icons/icon-map-pin.svg")} alt="" width={28} height={28} />
                <span>Home visits only. Based in {site.base}.</span>
              </li>
            </ul>

            <h2 style={{ fontSize: "1.7rem" }}>What happens next</h2>
            <ol className="prose" style={{ paddingLeft: "1.2em" }}>
              <li>I reply within one working day to book the free call.</li>
              <li>We talk for 15 minutes about what's going on.</li>
              <li>If we agree to go ahead, we book your first home visit.</li>
            </ol>

            <div style={{ marginTop: 32 }}>
              <CrisisNote />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
