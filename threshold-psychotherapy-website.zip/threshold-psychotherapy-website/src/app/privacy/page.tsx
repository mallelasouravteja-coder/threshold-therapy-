import type { Metadata } from "next";
import { PageIntro } from "@/components/Blocks";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Notice",
  description: `How ${site.name} collects, uses and protects your personal information.`,
  alternates: { canonical: "/privacy/" },
  robots: { index: false, follow: true },
};

// ⚠️ Template only. Have this reviewed so it matches how you actually store data
// (your CRM, notes system and email provider) before launch.
export default function PrivacyPage() {
  return (
    <>
      <PageIntro title="Privacy notice" crumb="Privacy" />
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container prose">
          <p>
            {site.name} is the data controller for information you share with us, and is registered with
            the Information Commissioner's Office (ICO).
          </p>
          <h2>What we collect</h2>
          <p>
            When you use the enquiry form we collect your name, email, phone number, postcode, the type of
            help you're interested in, preferred times and anything you choose to tell us.
          </p>
          <h2>How we use it</h2>
          <ul>
            <li>To reply to your enquiry and arrange a free call</li>
            <li>To check whether you're in our visiting area</li>
            <li>If you become a client, to provide and manage your therapy</li>
          </ul>
          <p>
            Our lawful basis is your consent for enquiries, and for clients, the provision of health care
            under UK GDPR Article 9(2)(h).
          </p>
          <h2>Where it's stored</h2>
          <p>
            Enquiries are sent securely to our client management system. We never sell your information
            or use it for marketing.
          </p>
          <h2>How long we keep it</h2>
          <p>
            Enquiries that don't lead to therapy are deleted after 12 months. Clinical records are kept
            for 8 years after therapy ends, in line with professional guidance.
          </p>
          <h2>Your rights</h2>
          <p>
            You can ask to see, correct or delete your information at any time by emailing{" "}
            <a href={`mailto:${site.email}`}>{site.email}</a>. You can also complain to the{" "}
            <a href="https://ico.org.uk/make-a-complaint/" rel="noopener">ICO</a>.
          </p>
          <h2>Cookies</h2>
          <p>This website doesn't use tracking or advertising cookies.</p>
        </div>
      </section>
    </>
  );
}
