import type { Metadata } from "next";
import Link from "next/link";
import { CtaBand, JsonLd, PageIntro } from "@/components/Blocks";
import { asset, services, site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Therapy Services: Anxiety, Depression, Couples, Trauma & EMDR",
  description:
    "Home-visit therapy in East London for anxiety, depression, couples and relationships, and trauma/PTSD with EMDR. Evidence-based, NICE-recommended approaches.",
  alternates: { canonical: "/services/" },
};

export default function ServicesPage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: services.map((s, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: {
        "@type": "Service",
        name: `${s.name} therapy at home`,
        description: s.short,
        provider: { "@id": `${site.url}/#practice` },
        areaServed: "East London",
        offers: { "@type": "Offer", price: s.fee.replace("£", ""), priceCurrency: "GBP" },
      },
    })),
  };

  return (
    <>
      <PageIntro title="Therapy services" crumb="Services">
        <p>
          Four specialist areas, all delivered in your home. Every approach here is backed by research
          and recommended by NICE, the body that sets NHS treatment guidelines.
        </p>
        <ul className="jump" aria-label="Jump to a service">
          {services.map((s) => (
            <li key={s.slug}>
              <a href={`#${s.slug}`}>{s.name}</a>
            </li>
          ))}
        </ul>
      </PageIntro>

      <div className="container">
        {services.map((s) => (
          <section key={s.slug} id={s.slug} className="service" aria-labelledby={`${s.slug}-title`}>
            <div className="service__head">
              <img src={asset(`/images/icons/icon-${s.icon}.svg`)} alt="" width={64} height={64} />
              <h2 id={`${s.slug}-title`}>{s.name}</h2>
            </div>
            <div className="split split--top split--wide-left">
              <div>
                <p className="lede">{s.intro}</p>
                <h3>How we'll work</h3>
                <p>{s.approach}</p>
                <dl className="facts">
                  <div>
                    <dt>Typical length</dt>
                    <dd>{s.sessions.replace("Usually ", "")}</dd>
                  </div>
                  <div>
                    <dt>Each session</dt>
                    <dd>{s.length}</dd>
                  </div>
                  <div>
                    <dt>Fee</dt>
                    <dd>{s.fee}</dd>
                  </div>
                </dl>
                <Link href="/contact/" className="btn">
                  Ask about {s.name.split(" ")[0].toLowerCase()} therapy
                </Link>
              </div>
              <div className="panel">
                <h3>Can help with</h3>
                <ul className="ticks" style={{ marginBottom: 0 }}>
                  {s.helpsWith.map((h) => (
                    <li key={h}>{h}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>
        ))}
      </div>

      <section className="section section--paper">
        <div className="container">
          <h2>Not sure which fits?</h2>
          <p>
            You don't need to know what to call it. Many people come with a mix, like anxiety and low
            mood after a difficult birth. We'll work it out together in the free call.
          </p>
          <Link href="/faq/" className="btn btn--quiet">Read common questions</Link>
        </div>
      </section>

      <CtaBand />
      <JsonLd data={schema} />
    </>
  );
}
