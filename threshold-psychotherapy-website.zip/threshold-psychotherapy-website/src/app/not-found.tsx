import Link from "next/link";

export default function NotFound() {
  return (
    <section className="page-intro">
      <div className="container">
        <h1>This page doesn't exist</h1>
        <p>The link may be out of date. Try the home page or the list of services.</p>
        <div className="btn-row">
          <Link href="/" className="btn">Go to the home page</Link>
          <Link href="/services/" className="btn btn--quiet">See services</Link>
        </div>
      </div>
    </section>
  );
}
